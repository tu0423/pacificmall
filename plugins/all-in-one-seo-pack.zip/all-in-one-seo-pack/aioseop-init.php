<?php
/**
 * We'll eventually put stuff in here from the main plugin file.
 *
 * phpcs:disable Squiz.Commenting.FileComment.SpacingAfterComment
 *
 * @package All_in_One_SEO_Pack
 * @since 2.3.6
 */
