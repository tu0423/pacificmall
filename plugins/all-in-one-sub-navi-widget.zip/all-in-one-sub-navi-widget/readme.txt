=== All in One Sub Navi Widget ===
Contributors: jim912
Tags: Navigation
Requires at least: 3.0
Tested up to: 4.5
Stable tag: 1.0.3

Sub Navigation Widget. Display sub navigation auto matically on Page, Post and other WordPress pages. (Curren version japanese only.)

== Description ==
Sub Navigation Widget. Display sub navigation auto matically on Page, Post and other WordPress pages. (Curren version japanese only.)

== Changelog ==
= 1.0.3 =
* Compatible up to WordPress 4.5
* Fixed Deprecated Error.

= 1.0.2 =
* Compatible up to WordPress 4.0

= 1.0.1 =
* Compatible up to WordPress 3.4

= 1.0.0 =
* refine valuable typos.

= 0.3.5 =
* Public release


== Links ==
"[PS Auto Sitemap](http://wordpress.org/extend/plugins/ps-auto-sitemap/ "WordPress sitemap plugin")" is a plugin automatically generates a site map page from your WordPress site. 
It is easy to install for beginners and easy to customize for experts.
It can change the settings of the display of the lists from administration page, several neat CSS skins for the site map tree are prepared.

"[PS Disable Auto Formatting](http://wordpress.org/extend/plugins/ps-disable-auto-formatting/ "WordPress formatting plugin")"
Stops the automatic forming and the HTML tag removal in the html mode of WordPress, and generates a natural paragraph and changing line.